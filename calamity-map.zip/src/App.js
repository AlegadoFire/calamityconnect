import React, { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { createClient } from "@supabase/supabase-js";

const supabaseUrl = "YOUR_SUPABASE_URL";
const supabaseKey = "YOUR_SUPABASE_ANON_KEY";
const supabase = createClient(supabaseUrl, supabaseKey);

const icon = new L.Icon({
  iconUrl: "https://cdn-icons-png.flaticon.com/512/684/684908.png",
  iconSize: [35, 35],
});

export default function App() {
  const [position, setPosition] = useState(null);
  const [reports, setReports] = useState([]);
  const [category, setCategory] = useState("");
  const [photo, setPhoto] = useState(null);

  useEffect(() => {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setPosition([pos.coords.latitude, pos.coords.longitude]);
      },
      () => alert("Please enable GPS for accurate location.")
    );
  }, []);

  useEffect(() => {
    fetchReports();
    const interval = setInterval(fetchReports, 10000);
    return () => clearInterval(interval);
  }, []);

  async function fetchReports() {
    const { data } = await supabase.from("reports").select("*");
    setReports(data || []);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!position || !category) return alert("Please complete the form.");

    let photoUrl = null;
    if (photo) {
      const formData = new FormData();
      formData.append("image", photo);
      const res = await fetch(
        "https://api.imgbb.com/1/upload?key=YOUR_IMGBB_API_KEY",
        { method: "POST", body: formData }
      );
      const imgData = await res.json();
      photoUrl = imgData.data.url;
    }

    await supabase.from("reports").insert([
      {
        name: "Anonymous",
        category,
        latitude: position[0],
        longitude: position[1],
        photo_url: photoUrl,
      },
    ]);
    alert("Report submitted!");
    fetchReports();
  }

  return (
    <div>
      <h2 style={{ textAlign: "center" }}>🆘 Calamity Assistance Map</h2>

      {position && (
        <MapContainer center={position} zoom={15} style={{ height: "70vh" }}>
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          <Marker position={position} icon={icon}>
            <Popup>Your Location</Popup>
          </Marker>

          {reports.map((r) => (
            <Marker key={r.id} position={[r.latitude, r.longitude]} icon={icon}>
              <Popup>
                <b>{r.category}</b>
                <br />
                {r.photo_url && (
                  <img src={r.photo_url} alt="photo" width="100" />
                )}
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      )}

      <form onSubmit={handleSubmit} style={{ padding: 10 }}>
        <select onChange={(e) => setCategory(e.target.value)}>
          <option value="">Select Assistance Needed</option>
          <option value="🚒 BFP - Fire">🚒 BFP - Fire</option>
          <option value="🚓 Police">🚓 Police</option>
          <option value="🚑 Ambulance">🚑 Ambulance</option>
          <option value="🎒 Relief Goods">🎒 Relief Goods</option>
        </select>
        <input
          type="file"
          accept="image/*"
          onChange={(e) => setPhoto(e.target.files[0])}
        />
        <button type="submit">Submit Report</button>
      </form>
    </div>
  );
}
